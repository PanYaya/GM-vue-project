<template>
  <div class="meddle">
    <img src="../../../assets/1img/meddle.png" alt="">
  </div>
</template>

<script>
export default {
  name: 'meddle'
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
  .meddle{
    width: 100%;
    height: 1.17rem;
  }
  .meddle img{
    width: 100%;
    height: 100%;
  }
</style>
