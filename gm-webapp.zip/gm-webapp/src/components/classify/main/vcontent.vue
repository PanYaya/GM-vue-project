<template>
  <div class="vcontent">
    <div  v-for="(v,sid) in data.arr" :key="sid"  :sid="sid" >
      <p>{{v.title}}</p>
      <ul >
        <shop-product v-for="(val,sid) in v.products" :key="sid"  :data="val" :sid="sid"></shop-product>
      </ul>
    </div>
    <p>热门品牌</p>
    <ul class="hot">
      <li v-for="(n,k) in data.imgurl" :key="k">
        <a href="">
          <img :src="n" alt="">
        </a>
      </li>
    </ul>
  </div>
</template>

<script>
import item from './item'
export default {
  name: 'vcontent',
  components: {
    'shop-product': item
  },
  props: ['data', 'sid']
}
</script>

<style scoped>
  .vcontent{
    width:77%;
    height: 100%;
    padding: 0.08rem 0rem 0.08rem 0.08rem;
    /* padding: 0.08rem; */
    float: left;
  }
 p{
    padding-bottom:0.1rem;
    color: gray;
    font-size: 0.12rem;
  }
  .vcontent>div ul{
    width: 100%;
     height: 1.15rem;
    display: flex;
  }
  .hot{
    width: 100%;
    display: flex;
    flex-direction: row;
    flex-wrap: wrap;
    justify-content: space-between;
  }
  .hot li{
    height:0.5rem;
    width: 30%;
  }
  .hot li img{
    width: 100%;
    height: 100%;
    display: block;
  }
</style>
