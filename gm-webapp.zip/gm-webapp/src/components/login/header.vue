<template>
  <div class="top">
    <a href="">
      <img src="http://39.107.139.165/5img/top1.png" alt="">
    </a>
  </div>
</template>

<script>
export default {
  name: 'vheader'
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
  .top{
    width: 90%;
    height: 0.53rem;
    padding: 0rem 0.12rem;
    box-sizing: border-box;
    background-color: white;
    position: relative;
  }
  .top a img{
    width: 0.3rem;
    height: 0.44rem;
  }
</style>
